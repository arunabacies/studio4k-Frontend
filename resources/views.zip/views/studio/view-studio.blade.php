@extends('layouts.app')

@section('content')

@php 
  $pm = array();
  $crew_list = array();
	$engineer = array();
  $client = array();

  $creator = $data->creator;
	$assigned_users = $data->assigned_users;
  $sessions = $data->sessions; 

  $presenters_count = 0;
  if($sessions) {
    foreach($sessions as $session) {
      $presenters_count = $presenters_count + $session->presenters;
    }
  }

  foreach($assigned_users as $assigned_user) {
                        
    if($assigned_user->user_role == 2) {
      array_push($pm,$assigned_user->name);
    }
		if($assigned_user->user_role == 5) {
		  array_push($crew_list, $assigned_user->name);
		} else if($assigned_user->user_role == 4) {
		  array_push($engineer, $assigned_user->name);
		} else if ($assigned_user->user_role == 3) {
      array_push ($client, $assigned_user->name);
    }        

  }
							
@endphp
  
<!-- Basic card section start -->
<section id="content-types">
  
  <div class="row">

    <div class="col-sm-12">
      <div class="card">
        <div class="card-header">
          <h1 class="text-bold-400">{{ $data->name }}</h1>
        <div>
        
        <button class="btn btn-success" onClick="window.location.reload();">
          <i class="bx bx-refresh">&nbsp;</i>Refresh
        </button>
      </div>
    </div>

    <div class="card-body">
      <hr class="m-0"/>
      <div class="row justify-content-between">
        <div class="col-md-5 col-sm-6">
          <div class="d-flex mb-2 pt-2" style="flex-wrap: wrap;">
            
            <p class="w-50 mb-50 text-primary">Created By: {{ $creator->name }}</p>
            <p class="w-50 mb-50 text-primary">Date: {{ date('d-m-Y', strtotime($data->created_at)) }}</p>
            <p class="w-50 mb-50 text-primary">Project Manager: {{ implode(", ", $pm) }}</p>
            <p class="w-50 mb-50 text-primary">Job: {{$data->job_number}}</p>
            <p class="w-100 mt-1">
              <span class="d-inline-block text-success mr-1">
                <i class="bx bx-globe" style="font-size: 45px;"></i>
              </span>
              <span id="gttz" class="d-inline-block text-success">{{ $timezone->zone }}
                  <small class="d-block text-success"></small>
              </span>
            </p>
            
          </div>
        </div>

        <div class="col-md-3 col-sm-5">
          <div class="d-flex mb-2 pt-2" style="flex-wrap: wrap;">
            <h4 class="w-50 mb-50 text-white">Sessions:</h4>
            <h4 class="w-50 text-right mb-50 text-white">{{ count($sessions) }}</h4>
            <p class="w-50 mb-50">Crews:</p>
            <p class="w-50 text-right mb-50">{{ count($crew_list) }}</p>
            <p class="w-50 mb-50">Presenters:</p>
            <p class="w-50 text-right mb-50">{{ $presenters_count }}</p>
          </div>
        </div>

      </div>

    </div>
    </div>
    </div>

  </div>
</section>
<!-- Basic Card types section end -->

<!-- Data table -->
<section id="session-datatable">
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h3 class="text-white">Sessions</h3>
          @if (Session::get('role') == 1)
          <button class="btn btn-warning create-session" data-toggle="modal" 
            data-target="#newStudioSession" assigned-users="{{ json_encode($assigned_users) }}">
            <i class="bx bx-plus-circle">&nbsp;</i>New Session
          </button>
          @endif
        </div>
        
        <div class="card-body card-dashboard">
          <div class="table-responsive">
            <table class="table zero-configuration">
              <thead>
                <tr>
                  <th>Session</th>
                  <th>Date</th>
                  <th>Presenters</th>
                  @if (Session::get('role') == 1)
                  <th>Go to Session</th>
                  @endif
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
						
                @if($sessions)
                  @foreach($sessions as $session)
                  @php 
                    
                    $presenters = $session->presenters;
                    
                   
                    $state_to_be = "";
                    $title ="";
                    $style_pointer = '';
                    if($session->state == 'upcoming') {
                      $terminate_class = 'bx-play';
                      $state_to_be = "running";
                      $title = "Start";
                    } else if($session->state == 'running'){
                      $terminate_class = 'bx-x-circle';
                      $state_to_be = "closed";
                      $title = "Terminate";
                    } else if($session->state == 'closed') {
                      $terminate_class = 'bx-stop';
                      $style_pointer = 'style=pointer-events:none';
                    }
                    if($session->start_recording == true) {
                      $recording_icon = 'bx-circle text-danger' ;
                      $recording_title = 'Stop';
                    } else {
                      $recording_icon = 'bx-log-in-circle text-warning';
                      $recording_title = 'Start';
                    }
                  @endphp

                  <tr>
                    <td>{{ $session->name }} </td>
                    <td>{{ date('d-m-Y', strtotime($session->session_time)) }}</td>
                    <td>{{ $presenters }}</td>
                    @php if ($presenters != 0) {
                      $href = "https://pohostaging.club/oasis-connect-rooms/dashboard/".$session->id."/". Session::get('token');
                      $target = 'target="_blank"';
                    } else {
                      $href = "#";
                      $target = '';
                    }
                    @endphp
                    @if (Session::get('role') == 1)
                    <td>
                      <a class="btn btn-danger" href="{{$href}}" {{$target}}>Go</a>
                    </td>
                    @endif
                    
                    <td>
                    <span data-toggle="popover" data-placement="top" data-trigger="hover"
                        data-container="body" data-content="Click Here to start Recording" 
                        {{$style_pointer}}>
                        <i class="bx {{ $recording_icon }} studio-session-record" data-toggle="modal" 
                            data-url="{{ route('studio-record-session') }}" 
                            data-id="{{ $session->id}}" 
                            studio-id="{{ $data->id }}"
                            start-recording="{{ $session->start_recording }}" 
                            title="{{ $recording_title }}" ></i>
                      </span>
                      <span data-toggle="popover" data-placement="top" data-trigger="hover"
                        data-container="body" data-content="Click Here to add Presenters" 
                        {{$style_pointer}}>
                        <i class="bx bx-plus-circle text-success session-add-presenter" 
                          data-toggle="modal" 
                          data-target="#addSessionPresenter"
                          session-id="{{ $session->id}}" 
                          project-id="{{ $data->id }}"
                          url="{{ route('get-studio-presenter') }}">
                        </i>
                      </span>
                      
                      @if($presenters > 0)
                        <span data-toggle="popover" data-placement="top" data-trigger="hover"
                          data-container="body" data-content="Click Here to send mail" 
                          {{$style_pointer}}>
                          <i class="bx bx-mail-send text-primary send-mail-button" 
                            session-id="{{ $session->id}}"
                            presenters="{{ json_encode($presenters) }}" 
                            url="{{ route('studio-presenter-email-sent') }}"></i>
                        </span>
                      @endif

                      <span data-toggle="popover" data-placement="top" data-trigger="hover"
                        data-container="body" data-content="Click Here to {{ $title }} Session" 
                        {{$style_pointer}}>
                        <i class="bx {{$terminate_class}} text-danger terminate-session" 
                          data-id="{{ $session->id}}" 
                          data-name="{{$session->name}}" 
                          data-url="{{route('terminate-studio-session')}}" 
                          title="{{ $title }}" 
                          state_to_be="{{ $state_to_be }}"></i>
                      </span>
                      
                      <span data-toggle="popover" data-placement="top" data-trigger="hover"
                        data-container="body" data-content="Click Here to edit Session" 
                        {{$style_pointer}}>
                        <i class="bx bx-edit-alt text-warning sessionEdit" data-toggle="modal" 
                            data-target="#editstudioSession"
                            data-url="{{ route('get-session') }}" 
                            data-id="{{ $session->id}}" 
                            project-id="{{ $data->id }}"
                            assigned-users="{{ json_encode($assigned_users) }}" 
                            timezone="{{ $timezone->zone }}"
                            title="Edit" ></i>
                      </span>
                      

                      
                      <span data-toggle="popover" data-placement="top" data-trigger="hover"
                        data-container="body" data-content="Click Here to delete Session">
                        <i class="bx bx-trash text-danger deleteEvent" 
                          data-id="{{$session->id}}" 
                          data-name="{{$session->name}}" 
                          data-url="{{route('delete-studio-session')}}"
                          project-id="{{$data->id}}"></i>
                      </span>
                    </td>
                  </tr>

                @endforeach
                @endif   
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--/ Data table -->

<!-- Data table -->
<section id="project-user-datatable">
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h3 class="text-white">Users</h3>
        </div>
        <div class="card-body card-dashboard">
          <div class="table-responsive">
            <table class="table zero-configuration">
              <thead>
                <tr>
                  <!-- <th>ID</th> -->
                  <th>Name</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>

                @foreach ($assigned_users as $assigned_user)
                  @php 
                    if($assigned_user->user_role == 1) {
                      $role = "Admin";
                    } else if($assigned_user->user_role == 2) {
                      $role = "Project Manager";
                    } else if($assigned_user->user_role == 3) {
                      $role = "Client";
                    } else if($assigned_user->user_role == 4) {
                      $role = "Engineer";
                    } else {
                      $role = "Crew";
                    }
                  @endphp
              
                  <tr>
                    <td>{{ $assigned_user->name }}</td>
                    <td>{{ $assigned_user->email }}</td>
                    <td>{{ $role }}</td>
                    <td>
                      <span data-toggle="popover" data-placement="top" data-trigger="hover"
                        data-container="body" data-content="Click Here to delete User" 
                        class="removeUser" 
                        data-id="{{ $assigned_user->user_id }}" 
                        project-id="{{$data->id}}" 
                        data-name="{{ $assigned_user->name }}" 
                        data-url="{{route('remove-user')}}">
                        <i class="bx bx-trash text-danger "></i>
                      </span>
                    </td>
                  </tr>

                @endforeach
                          
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--/ Data table -->
		
@endsection

@section('pagespecificscripts')
    <!-- flot charts scripts-->
    <script src="{{ asset('assets/js/studio.js') }}"></script>
@stop
