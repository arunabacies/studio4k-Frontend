@extends('layouts.app')

@section('content')

<h3 style="text-align: center;color: #a6a1a1;">
    Something went wrong! Please try again
</h3>

@endsection