<?php use App\Http\Controllers\ProjectController; $ProjectController= new ProjectController(); ?>

@extends('layouts.app')

@section('content')
<!-- Basic card section start -->
<section id="content-types mb-1">
  <div class="row">
    <div class="col-12 mb-1">
      <div class="d-flex justify-content-between">
        <h1>Recordings</h1>
      </div>
      <hr/>
    </div>
  </div>
</section>
<!-- Basic Card types section end -->

<!-- Data table -->
<section id="recording-datatable">
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h3 class="text-white">Recordings</h3>
        </div>
        <div class="card-body card-dashboard">
          <div class="table-responsive">
            <table class="table zero-configuration">
              <thead>
                <tr>
                  <!-- <th>ID</th> -->
                  <th>Event Name</th>
                  <th>Event Time</th>
                  <th>Project</th>
                  <th>Room</th>
                  <th>URL</th>
                </tr>
              </thead>
              <tbody>
                @if($data)
                @foreach($data as $recording)
                
                  <tr>
                    <td>{{$recording->event_name}}</td>
                    <td>{{$recording->event_time}}</td>
                    <td>{{$recording->project_name}}</td>
                    <td>{{$recording->name}}</td>
                    
                    <td>
                      <a href="{{$recording->url}}" target="_blank">
                        <i class="bx bx-play" style="color: #5a8dee !important;" ></i>
                      </a>
                    </td>
                    
                  </tr>

                @endforeach
                @endif
              </tbody>
            </table>
            
            @if($data)
                
                <div class="pagination">
                    <p class="result-info">Showing {{$data->firstItem()}}-{{$data->lastItem()}} results of {{$data->total()}}</p>
                    <!-- <button class="an-btn an-btn-transparent rounded uppercase small-font">Show More</button> -->
                    {!!$ProjectController->paginate_with_custom_path($data)!!}
                  </div>
               
            @endif

          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--/ Data table -->

@endsection
